﻿//Author: Jonathan Rozeff, Date: 2/26/19, Homework: 3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Rozeff_Jonathan_HW3.Models
{
    //Method for GuestResponse
    public class GuestResponse
    {
        //Auto-implemented properties with data validations
        [Required(ErrorMessage = "Please enter your name")]
        public string Name { set; get; }

        [Required(ErrorMessage = "Please enter your email address")]
        [RegularExpression(".+\\@.+\\..+", ErrorMessage = "Please enter a valid email message")]
        public string Email { set; get; }

        [Required(ErrorMessage = "Please enter your phone number")]
        public string Phone { set; get; }

        [Required(ErrorMessage = "Please specify whether you'll attend")]
        public bool? WillAttend { set; get; }
    }
}
