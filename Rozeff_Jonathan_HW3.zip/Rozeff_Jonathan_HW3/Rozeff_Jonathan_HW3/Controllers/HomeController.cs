﻿//Author: Jonathan Rozeff, Date: 2/26/19, Homework: 3

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Rozeff_Jonathan_HW3.Models;

namespace Rozeff_Jonathan_HW3.Controllers
{
    //Controller
    public class HomeController : Controller
    {
        //Action Method View that displays greeting based on time of day
        public ViewResult Index()
        {
            int hour = DateTime.Now.Hour;
            ViewBag.Greeting = hour < 12 ? "Good Morning" : "Good Afternoon";
            return View("MyView");
        }


        //Method that responds to HTTP GET requests
        [HttpGet]
        //Action Method that displays the RsvpForm 
        public ViewResult RsvpForm()
        {
            return View();
        }


        //Method that responds to HTTP POST requests
        [HttpPost]
        //Action Method that displays the Thanks form with decision structure for validation 
        public ViewResult RsvpForm(GuestResponse guestResponse)
        {
            if (ModelState.IsValid)
            {
                Repository.AddResponse(guestResponse);
                return View("Thanks", guestResponse);
            }
            else
            {
                //there is a validation error
                return View(guestResponse);
            }
        }


        //Action Method that displays the ListResponses form 
        public ViewResult ListResponses()
        {
            return View(Repository.Responses.Where(r => r.WillAttend == true));
        }
    }
}
